<?php
$host = 'localhost';
$user = 'warqaandqalam';
$pass = '0x3b3fc/lol';
$db = 'warqaandqalam';

$conn = mysqli_connect($host,$user,$pass,$db);
