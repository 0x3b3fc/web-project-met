<?php
include('public/header.php');
?>

<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="post">
                    <h1>عن المدونة</h1>
                    <h4>المدونة هي مشروع خاص ببعض الطلاب من الفرقة الثالثة شعبة علوم الحاسب</h4>
                    <h4>تحت قيادة الدكتور محمد كاظم</h4>
                    <h4>اسماء الطلاب المشاركين في المشروع</h4><br>
                    <h5>سيف هشام عبدالهادي - عبدالرحمن الحجاج الفلاح</h5>
                    <h5>احمد الحسيني - عبدالرحمن هلال</h5>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include('public/footer.php');
?>