  <!-- Footer Section Start -->
  <footer>
    <p>جميع الحقوق محفوظة &copy; 2022</p>
  </footer>
  <!-- Footer Section end -->

  <!-- bootstrap js files start -->
  <script src="js/jquery-3.6.0.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <!-- bootstrap js files end -->

  <!-- fontawesome file start -->
  <script src="https://kit.fontawesome.com/d2b9f98588.js" crossorigin="anonymous"></script>
  <!-- fontawesome file end -->
</body>

</html>